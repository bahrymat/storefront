Online Storefront Creator
==========

see readme.html for info



to get mongo working: 

install mongo somewhere outside the repo (https://gist.github.com/soheilhy/30e503d1c6b3215c034f)
install mongoose inside the repository
run mongo on port 8081 using bin/mongod --port 8081 --dbpath data/
